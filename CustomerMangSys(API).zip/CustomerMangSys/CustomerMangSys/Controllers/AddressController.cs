﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CustomerMangSys.Data;
using CustomerMangSys.Dtos;
using CustomerMangSys.Model;
using Microsoft.AspNetCore.Mvc;

namespace CustomerMangSys.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class AddressController : ControllerBase

    {
        private readonly ICustomer _info;
        private readonly IMapper _mapper;

        public AddressController(ICustomer info,IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }
        
        [HttpGet("{Id}")]
        public ActionResult<AddressReadDto> GetAddresses(int Id)
        {
            var add = _info.GetAddress(Id);
            return Ok(_mapper.Map<AddressReadDto>(add));
            
        }

        [HttpGet]
        public ActionResult<IEnumerable<AddressReadDto>>GetAddress(int Id)
        {
            var address = _info.GetAddresses();
            return Ok(_mapper.Map<List<AddressReadDto>>(address));
        }

        [HttpPost]
        public ActionResult<CustomerAddress> CreateAddress(AddressCreateDto addressCreateDto)
        {
            if (addressCreateDto != null)
            {
                var newAddress = _mapper.Map<CustomerAddress>(addressCreateDto);
                _info.CreateAddress(newAddress);
                return Ok(addressCreateDto);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{Id}")]
        public ActionResult<AddressUpdateDto> UpdateAddress(AddressUpdateDto addressUpdateDto, int Id)
        {
            var cust = _info.GetAddress(Id);

            if (addressUpdateDto != null)
            {
                _mapper.Map(addressUpdateDto, cust);
                _info.UpdateAddress(cust);
                return Ok();
            }
            else
            {
                return NotFound();

            }
        }

          [HttpDelete("{Id}")]
       
        //public ActionResult<AddressReadDto> DeleteAddress(AddressDeleteDto addressDeleteDto, int Id)
        public ActionResult<AddressDeleteDto>  DeleteAddress(AddressDeleteDto addressDeleteDto, int Id)
        {
            var cd = _info.GetAddress(Id);
            if (cd != null)
            {
                _mapper.Map(addressDeleteDto, cd);
                _info.DeleteAddress(cd);
                return Ok();
            }
            else
            {
                return NotFound();
            }
            
        }

    }
}
