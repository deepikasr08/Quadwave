﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CustomerMangSys.Data;
using CustomerMangSys.Dtos;
using CustomerMangSys.Model;
using Microsoft.AspNetCore.Mvc;

namespace CustomerMangSys.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomer _info;
        private readonly IMapper _mapper;

        public CustomerController(ICustomer info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }
        [HttpGet("{Id}")]
        public ActionResult<IEnumerable<CustomerReadDto>> GetCustomers(int Id)
        {
            var customer = _info.GetCustomer(Id);
            return Ok(_mapper.Map<CustomerReadDto>(customer));
        }
        [HttpGet]
        public ActionResult<IEnumerable<CustomerReadDto>> GetCustomer(int Id)
        {

            var customers = _info.GetCustomers();
            return Ok(_mapper.Map<List<CustomerReadDto>>(customers));
        }

        [HttpPost]

        public ActionResult<Customer> CreateCustomer(CustomerCreateDto customerCreateDto)
        {
            if (customerCreateDto != null)
            {
                var c = _mapper.Map<Customer>(customerCreateDto);
                _info.CreateCustomer(c);
                return Ok(customerCreateDto);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPut("{Id}")]
        public ActionResult updateCustmoer(CustomerUpdateDto customerUpdateDto, int Id)
        {
            var c = _info.GetCustomer(Id);
            if (c != null)
            {
                _mapper.Map(customerUpdateDto, c);
                _info.UpdateCustomer(c);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete("{Id}")]

        public ActionResult DeleteCustomer(CustomerDeleteDto customerDeleteDto,int Id)
        {
            var CusId = _info.GetCustomer(Id);
            if (CusId != null)
            {

               _mapper.Map(customerDeleteDto,CusId);
                _info.DeleteCustomer(CusId);
                return Ok();

            }
            return NotFound();


        }
    }
}

    
