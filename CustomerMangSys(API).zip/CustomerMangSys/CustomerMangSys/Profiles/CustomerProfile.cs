﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CustomerMangSys.Dtos;
using CustomerMangSys.Model;

namespace CustomerMangSys.Profiles
{
    public class CustomerProfile : Profile
    {
        public CustomerProfile()
            {
            CreateMap<CustomerCreateDto, Customer>();
            CreateMap<Customer, CustomerReadDto>();
            CreateMap<CustomerUpdateDto, Customer>();
            CreateMap<CustomerDeleteDto, Customer>();

            CreateMap<CustomerAddress, AddressReadDto>();
            CreateMap<AddressCreateDto, CustomerAddress>();
            CreateMap<AddressUpdateDto, CustomerAddress>();
            CreateMap<AddressDeleteDto,CustomerAddress>();
            
        }
    }
}
