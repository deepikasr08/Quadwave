﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerMangSys.Migrations
{
    public partial class AddCustAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into CustomerAddresses values(5,'India','Mysore','Bhogadi','9632587410')");
            migrationBuilder.Sql("insert into CustomerAddresses values(6,'India','Bangalore','RajajiNagar','6932587410')");
            
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
