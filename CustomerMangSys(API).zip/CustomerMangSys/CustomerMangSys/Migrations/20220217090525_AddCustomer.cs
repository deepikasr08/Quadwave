﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerMangSys.Migrations
{
    public partial class AddCustomer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into Customers values('Deepika','SR','02/17/2022 2:47:00')");
            migrationBuilder.Sql("insert into Customers values('Anusha','Ravish','02/18/2022 3:50:00')");
            migrationBuilder.Sql("insert into Customers values('Renuka','Yatagi','02/18/2022 12:05:05')");
           
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
