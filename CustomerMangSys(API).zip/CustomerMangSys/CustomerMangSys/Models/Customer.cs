﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerMangSys.Model
{
    public class Customer
    {
        public int CustomerId { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public DateTime CreateDate { set; get; }
        

    }
}
