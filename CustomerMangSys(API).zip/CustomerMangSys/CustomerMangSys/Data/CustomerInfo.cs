﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerMangSys.Model;

namespace CustomerMangSys.Data
{
    public class CustomerInfo:ICustomer
    {
        private readonly CustomerContext _context;

        public CustomerInfo(CustomerContext context)
        {
            _context = context;
        }
        public Customer GetCustomer(int Id)
        {
            var customers = _context.Customers.SingleOrDefault(m => m.CustomerId == Id);
            return customers;
        }
        public List<Customer> GetCustomers()
        {
            var cust = _context.Customers.ToList();
            return cust;
        }
        public List<CustomerAddress> GetAddresses()
        {
            var Address = _context.CustomerAddresses.ToList();
            return Address;
        }

        public Customer CreateCustomer(Customer c)
        {
            _context.Customers.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateCustomer(Customer c)
        {
            _context.SaveChanges();
        }

        public void DeleteCustomer(Customer c)
        {
            _context.Remove(c);
            _context.SaveChanges();
        }

        public CustomerAddress GetAddress(int Id)
        {
            var cust = _context.CustomerAddresses.SingleOrDefault(m => m.Id == Id);
            return cust;
        }

        public CustomerAddress CreateAddress(CustomerAddress newAddress)
        {
            _context.CustomerAddresses.Add(newAddress);
            _context.SaveChanges();
            return newAddress;
        }


        public void DeleteAddress(CustomerAddress Cd)
        {
            _context.Remove(Cd);
            _context.SaveChanges();
        }

        public void UpdateAddress(CustomerAddress cust)
        {
            _context.SaveChanges();
        }
    }
}
