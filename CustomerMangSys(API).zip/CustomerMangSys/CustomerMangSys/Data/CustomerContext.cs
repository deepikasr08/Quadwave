﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerMangSys.Model;
using Microsoft.EntityFrameworkCore;

namespace CustomerMangSys.Data
{
    public class CustomerContext:DbContext
    {
        public CustomerContext(DbContextOptions<CustomerContext> opt) : base(opt)
        {

        }
        public DbSet<Customer> Customers { set; get; }
        public DbSet<CustomerAddress> CustomerAddresses { set; get; }
    }
}
