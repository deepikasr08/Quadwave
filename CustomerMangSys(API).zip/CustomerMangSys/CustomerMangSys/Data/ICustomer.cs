﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerMangSys.Model;

namespace CustomerMangSys.Data
{
    public interface ICustomer
    {
        public Customer GetCustomer(int Id);
        public List<Customer> GetCustomers();
       
        
        public Customer CreateCustomer(Customer c);
        public void UpdateCustomer(Customer c);
        public void DeleteCustomer(Customer c);

        public List<CustomerAddress> GetAddresses();
        public CustomerAddress GetAddress(int Id);

        public CustomerAddress CreateAddress(CustomerAddress newAddress);
        public void DeleteAddress(CustomerAddress Cd);
        
        public void UpdateAddress(CustomerAddress cust);
    }
}
