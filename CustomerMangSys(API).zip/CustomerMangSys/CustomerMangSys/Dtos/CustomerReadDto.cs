﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerMangSys.Dtos
{
    public class CustomerReadDto
    {
        public int CustomerId { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public DateTime CreateDate { set; get; }
    }
}
